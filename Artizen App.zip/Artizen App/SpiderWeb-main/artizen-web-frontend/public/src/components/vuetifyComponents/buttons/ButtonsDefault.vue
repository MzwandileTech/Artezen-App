<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Default -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="d-flex flex-wrap gap-2">
      
      <div>
        <v-btn color="primary">Primary</v-btn>
      </div>
      <div>
        <v-btn color="secondary">Secondary</v-btn>
      </div>
      <div>
        <v-btn color="error">Error</v-btn>
      </div>
      <div>
        <v-btn color="warning">Warning</v-btn>
      </div>
      <div>
        <v-btn color="success">Success</v-btn>
      </div>
      <div>
        <v-btn disabled>Disabled</v-btn>
      </div>
      <div>
        <v-btn>Normal</v-btn>
      </div>
  </div>
</template>
