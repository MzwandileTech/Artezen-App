<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Props -->
  <!-- ----------------------------------------------------------------------------- -->
  <v-card>
    <template v-slot:title> This is a title </template>

    <template v-slot:subtitle> This is a subtitle </template>

    <template v-slot:text> This is content </template></v-card
  >
</template>
