const profile = [
  {
    title: "My Profile",
    desc: "Account Settings",
  },
];

export { profile };
