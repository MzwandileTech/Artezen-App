<template>
  <div class="logo">
    <h2>Artizen App</h2>
  </div>
</template>
<script setup lang="ts">
import { RouterLink } from "vue-router";
</script>
