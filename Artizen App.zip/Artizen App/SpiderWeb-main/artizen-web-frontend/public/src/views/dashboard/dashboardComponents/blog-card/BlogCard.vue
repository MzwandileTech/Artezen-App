<script setup lang="ts">
</script>

<template>
  <v-row>
    <v-col cols="12" lg="4">
      <v-card>
        <img
          style="width: 100%"
          src="@/assets/images/background/u1.jpg"
        />
        <v-card-text>
          <h5 class="title font-weight-medium mb-2 text-h6">
           Yellow Mellow Art Painting
          </h5>

          <h5 class="title font-weight-medium mb-2 text-h6">
             R7 800
          </h5>

          <p class="mb-3 text-body-2 text-grey-darken-1">Artwork design by K Msimango, </p>
          <v-btn depressed color="warning">Buy Artwork</v-btn>
        </v-card-text>
      </v-card>
    </v-col>
    <v-col cols="12" lg="4">
      <v-card>
        <img
          style="width: 100%"
          src="@/assets/images/background/u2.jpg"
        />
        <v-card-text>
          <h5 class="title font-weight-medium mb-2 text-h6">
           Pinkish Painting
          </h5>
          <h5 class="title font-weight-medium mb-2 text-h6">
            R2 000
          </h5>
          <p class="mb-3 text-body-2 text-grey-darken-1">Artwork design by K Msimango, </p>
          <v-btn depressed color="error">Buy Artwork</v-btn>
        </v-card-text>
      </v-card>
    </v-col>
    <v-col cols="12" lg="4">
      <v-card>
        <img
          style="width: 100%"
          src="@/assets/images/background/u3.jpg"
        />
        <v-card-text>
          <h5 class="title font-weight-medium mb-2 text-h6">
            White Khalamari Painting
          </h5>
          <h5 class="title font-weight-medium mb-2 text-h6">
            R4 500
          </h5>
          <p class="mb-3 text-body-2 text-grey-darken-1">Artwork design by K Msimango, </p>
          <v-btn depressed color="info">Buy Artwork</v-btn>
        </v-card-text>
      </v-card>
    </v-col>
  </v-row>
</template>
